import React, {useState} from 'react';
import {AuthProvider} from './src/context/AuthContext';
import {NavigationContainer} from '@react-navigation/native';
import AppStack from './src/navigation/AppStack';
import Splash from './src/components/Splash';
import {ThemeProvider} from './src/context/ThemeContext';
// import AuthStack from './src/navigation/AuthStack';
// import AuthStack from './src/navigation/AuthStack';

function App(): JSX.Element {
  const [isAppReady, setAppReady] = useState(false);
  return !isAppReady ? (
    <Splash isReady={true} onAnimationFinish={() => setAppReady(true)} />
  ) : (
    <AuthProvider>
      <ThemeProvider>
        <NavigationContainer>
          <AppStack />
          {/* <AuthStack /> */}
        </NavigationContainer>
      </ThemeProvider>
    </AuthProvider>
  );
}

export default App;
