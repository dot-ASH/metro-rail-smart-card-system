/* eslint-disable react-native/no-inline-styles */
/* eslint-disable @typescript-eslint/no-unused-vars */
import React, {useContext} from 'react';
import {
  Dimensions,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  View,
  Animated,
  TouchableOpacity,
  useWindowDimensions,
} from 'react-native';
import {ThemeContext} from '../context/ThemeContext';
import {colors} from '../style/colors';

function TranHistory(): JSX.Element {
  const {darkMode, toggleOffDarkMode} = useContext(ThemeContext);
  const isDarkMode = darkMode;

  const backgroundStyle = {
    backgroundColor: isDarkMode ? colors.DARK : colors.LIGHT,
  };
  const textStyle = {
    color: isDarkMode ? colors.LIGHT_ALT : colors.DARK,
  };

  const textStyleAlt = {
    color: !isDarkMode ? colors.LIGHT_ALT : colors.DARK,
  };

  return (
    <SafeAreaView style={[backgroundStyle, styles.screenContainer]}>
      <StatusBar
        barStyle={isDarkMode ? 'light-content' : 'dark-content'}
        backgroundColor={colors.TRANPARENT}
        translucent={true}
      />
      <ScrollView
        contentInsetAdjustmentBehavior="automatic"
        style={[backgroundStyle, styles.screenContainer]}>
        <Text style={{fontSize: 27, color: 'white'}}>
          Lorem ipsum dolor sit, amet consectetur adipisicing elit. Molestias
          itaque officia magni, sit reiciendis nesciunt quae quam sed! Porro,
          maiores odio! Itaque, veritatis dicta. Obcaecati, odit tempore cum
          corrupti non laborum soluta excepturi officia exercitationem expedita,
          velit vel, culpa natus sed voluptates nulla similique reprehenderit
          nobis! Soluta sed fugit molestias optio! Officiis
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screenContainer: {
    flexDirection: 'column',
    height: Dimensions.get('window').height + 80,
    width: Dimensions.get('window').width,
    marginBottom: 100,
  },
});
export default TranHistory;
