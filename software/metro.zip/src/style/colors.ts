export const colors = {
  TRANPARENT: '#00000000',
  LIGHT: '#F1EAE4',
  LIGHT_ALT: '#f6f2ef',
  LIGHT_HIGHLIGHTED: '#69625d',
  DARK: '#322E2F',
  DARK_ALT: '#2D2A2A',
  DARK_LIGHT: '#938585',
  DARK_HIGHLIGHTED: '#b9a6ac',
  VERIFIED: '#84a98c',
  ERROR: '#fe6d73',
};
