export const fonts = {
  Bree: 'Bree Serif Regular',
  Vollkorn: 'Vollkorn Regular',
  Karma: 'Karma Medium',
  KarmaBold: 'Karma Bold',
  KarmaSemiBold: 'Karma SemiBold',
  Quantico: 'Quantico Regular',
  QuanticoBold: 'Quantico Bold',
  SourceCodeProBold: 'Source Code Pro Bold',
  SourceCodeProSemiBold: 'Source Code Pro SemiBold',
};
