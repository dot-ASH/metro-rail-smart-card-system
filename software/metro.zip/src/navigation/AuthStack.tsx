import React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
// import OnboardingScreen from '../screens/OnboardingScreen';
// import OTPScreen from '../screens/OTPScreen';
import VerifyScreen from '../screens/VerifyScreen';
import appStack from './AppStack';

export type AuthStackParamList = {
  Onboarding: undefined;
  Login: undefined;
  Verify: undefined;
  AppStack: undefined;
};

const Stack = createNativeStackNavigator<AuthStackParamList>();

const AuthStack = () => {
  return (
    <Stack.Navigator screenOptions={{headerShown: false}}>
      {/* <Stack.Screen name="Onboarding" component={OnboardingScreen} />
      <Stack.Screen name="Login" component={OTPScreen} /> */}
      <Stack.Screen name="Verify" component={VerifyScreen} />
      <Stack.Screen name="AppStack" component={appStack} />
    </Stack.Navigator>
  );
};

export default AuthStack;
