declare module '@env' {
  export const SUPABASE_KEY: string;
  export const API_URL: string;
}
