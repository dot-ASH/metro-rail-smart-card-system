## Database Playground

Use this as a template to explore your supabase feature! Please make sure to enable RLS, you can enhance security with user authentication feature