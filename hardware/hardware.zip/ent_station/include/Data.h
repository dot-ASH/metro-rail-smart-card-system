String supabase_url = "https://unhvsygaohvjoeuxbans.supabase.co";
String anon_key = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVuaHZzeWdhb2h2am9ldXhiYW5zIiwicm9sZSI6ImFub24iLCJpYXQiOjE2OTQzNzcwNzUsImV4cCI6MjAwOTk1MzA3NX0.kSVenX8kjuaZ8ywhP7ahroy-fQkPuzWeBpiL9YLKIpU";
const char* serverURL = "http://192.168.0.7:5000/body-info";
const char kHostname[] = "http://192.168.0.7:5000";
const char kPath[] = "/body-info";
int shift = 15;
int secretKey = 1024;
